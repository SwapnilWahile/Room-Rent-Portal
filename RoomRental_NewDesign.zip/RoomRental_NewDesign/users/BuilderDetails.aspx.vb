﻿
Partial Class users_BuilderDetails
    Inherits System.Web.UI.Page

End Class
