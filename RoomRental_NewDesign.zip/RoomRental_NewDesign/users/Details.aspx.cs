﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class users_Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        hfID.Value = Request.QueryString["id"].ToString();
        hfDate.Value = DateTime.Now.ToString();
       // Response.Write(Request.QueryString["u"].ToString());
        checkStatus();
    }
    private void checkStatus()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select status from  Booking where pid=" + Request.QueryString["id"].ToString();
        cmd.Connection = con;
        object obj = cmd.ExecuteScalar();
        if (obj == null)
        {
            //hfid.Value = "1";
        }
        else
        {
            if (obj.ToString() == "Book")
            {
                //Response.Write(obj);
               // btnBook.Enabled = false;
                lblmsg.Text = "Property Already Booked !";
            }
        }
        con.Close();
    }

    protected void btnBook_Click(object sender, EventArgs e)
    {
        SqlDataInsert.Insert();
        //btnBook.Enabled = false;
        lblmsg.Text = "Property Book By You Successfully !";
    }
}